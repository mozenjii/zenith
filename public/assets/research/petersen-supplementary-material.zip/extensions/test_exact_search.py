"""Independent brute-force check of modular candidate generation."""
import itertools
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'outputs'))
from exact_search import exact_parameters, read_candidates

for n in range(9, 31):
    candidates = read_candidates(Path(sys.argv[1]), n, n)
    generated = {m for level, m in candidates if level == n}
    expected = {m for m in itertools.combinations(range(1, (n+1)//2), 4)
                if exact_parameters(n, m) is not None}
    assert expected <= generated, (n, expected-generated)
    retained = {m for m in generated if exact_parameters(n, m) is not None}
    assert retained == expected, n
    print(f'PASS n={n}: all {len(expected)} nondegenerate exact solutions retained', flush=True)
