#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <stdint.h>
/* Exact first-force-anchored search. GCC 128-bit extension; 7 <= n <= 64. */
typedef __uint128_t Bits;
static Bits adj[128],full;
static int nv;
static Bits bit(int i){return ((Bits)1)<<i;}
static int low(Bits t){uint64_t a=(uint64_t)t;return a?__builtin_ctzll(a):64+__builtin_ctzll((uint64_t)(t>>64));}
static void build(int n){
 nv=2*n; full=nv==128?~(Bits)0:bit(nv)-1;
 for(int i=0;i<n;i++){
 adj[i]=bit((i+1)%n)|bit((i+n-1)%n)|bit(n+i);
 adj[n+i]=bit(i)|bit(n+(i+3)%n)|bit(n+(i+n-3)%n);
 }
}
static int forces(Bits s){
 /* Each initially blue vertex is queued. A vertex whose white-neighbor
 count falls to one is queued at the only event that could enable it. */
 int q[512],head=0,tail=0; unsigned char queued[128]={0};
 for(Bits t=s;t;t&=t-1){int x=low(t);q[tail++]=x;queued[x]=1;}
 while(head<tail){
 int x=q[head++]; Bits w=adj[x]&~s;
 if(w && !(w&(w-1))){
 int y=low(w);s|=w;
 if(!queued[y]){q[tail++]=y;queued[y]=1;}
 for(Bits t=adj[y]&s;t;t&=t-1){int z=low(t);Bits rem=adj[z]&~s;
 if(rem && !(rem&(rem-1))) q[tail++]=z;
 }
 }
 }
 return s==full;
}
static unsigned long long tested;
static int reference(Bits s){
 int changed=1;
 while(changed){changed=0;
 for(int x=0;x<nv;x++)if(s&bit(x)){Bits w=adj[x]&~s;
 if(w&&!(w&(w-1))){s|=w;changed=1;}}
 }
 return s==full;
}
static int complete(Bits seed,int r,Bits *answer){
 int avail[128],a=0,ix[8],k=r-__builtin_popcountll((uint64_t)seed)-__builtin_popcountll((uint64_t)(seed>>64));
 for(int i=0;i<nv;i++)if(!(seed&bit(i)))avail[a++]=i;
 if(k<0)return 0;
 for(int j=0;j<k;j++)ix[j]=j;
 for(;;){Bits s=seed;for(int j=0;j<k;j++)s|=bit(avail[ix[j]]);
 tested++; if(forces(s)){*answer=s;return 1;}
 int j=k-1;while(j>=0&&ix[j]==a-k+j)j--;
 if(j<0)return 0;
 ix[j]++;for(int h=j+1;h<k;h++)ix[h]=ix[h-1]+1;
 }
}
static int anchored(int n,int r,Bits *ans){
 Bits seeds[4]={bit(0)|bit(n-1)|bit(1),bit(0)|bit(1)|bit(n),bit(n)|bit(2*n-3)|bit(n+3),bit(n)|bit(n+3)|bit(0)};
 for(int j=0;j<4;j++)if(complete(seeds[j],r,ans))return 1;
 return 0;
}
static int number(const char *s){char *end;errno=0;long x=strtol(s,&end,10);return errno||*end||x<0||x>128?-1:(int)x;}
int main(int argc,char **argv){
 if(argc<3||argc>4){fprintf(stderr,"usage: program nlo nhi [selftest]\n");return 2;}
 int lo=number(argv[1]),hi=number(argv[2]);
 if(lo<7||hi<lo||hi>64){fprintf(stderr,"require 7 <= nlo <= nhi <= 64\n");return 2;}
 for(int n=lo;n<=hi;n++){
 build(n);Bits answer=0;tested=0;
 if(argc==4){
 if(n<=9)for(Bits s=0;s<=full;s++)if(forces(s)!=reference(s)){fprintf(stderr,"closure mismatch %d\n",n);return 1;}
 for(int r=3;r<=7;r++){int a=anchored(n,r,&answer),b=complete(0,r,&answer);if(a!=b){fprintf(stderr,"mismatch %d %d\n",n,r);return 1;}}
 printf("selftest n=%d PASS\n",n);}
 else {int found=anchored(n,7,&answer);Bits eight=0;for(int i=0;i<8;i++)eight|=bit(i);
 printf("n=%d seven_exists=%d eight_outer_forces=%d tested=%llu",n,found,n>=8?forces(eight):0,tested);
 if(found){printf(" witness=");for(int i=0;i<nv;i++)if(answer&bit(i))printf("%c%d,",i<n?'u':'v',i%n);}
 puts("");}
 fflush(stdout);
 }
 return 0;
}
