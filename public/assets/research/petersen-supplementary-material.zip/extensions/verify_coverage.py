"""Exact natural density of the verified divisibility families."""
from fractions import Fraction
from itertools import combinations
from math import lcm

BASES = (10,16,17,18,19,21,22,23,24,25,26,27,28,29,31)

def density(bases):
    return sum(((-1)**(r+1)*sum(
        (Fraction(1,lcm(*s)) for s in combinations(bases,r)),Fraction())
        for r in range(1,len(bases)+1)),Fraction())

if __name__ == '__main__':
    assert density((10,24,28,42)) == Fraction(1,6)
    result = density(BASES)
    assert result == Fraction(6933083,14969435)
    print(f'Zero-forcing family density: {result} = {float(result):.12%}')
