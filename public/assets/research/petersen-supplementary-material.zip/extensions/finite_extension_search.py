"""Exploratory exact reduction of cosine configurations to finite fields."""
import itertools,json,sys
from pathlib import Path
import sympy as s
z=s.Symbol('z')

def search(n,limit=300):
    phi=s.Poly(s.cyclotomic_poly(n,z),z)
    zero=s.Poly(0,z)
    cs={m:s.Poly(z**m+z**(n-m),z).rem(phi) for m in range(1,(n+1)//2)}
    for count,ms in enumerate(itertools.combinations(cs,4)):
        if count>=limit:break
        c=[cs[m] for m in ms]
        f=(3+sum((a*b for a,b in itertools.combinations(c,2)),zero)).rem(phi)
        if f.is_zero:continue
        norm=abs(int(s.resultant(phi,f)))
        if norm<2:continue
        p=-sum(c,zero)
        q=(3*p-sum((a*b*d for a,b,d in itertools.combinations(c,3)),zero)).rem(phi)
        tau=(p*q-c[0]*c[1]*c[2]*c[3]).rem(phi)
        for ell in s.factorint(norm):
            ell=int(ell)
            if n%ell==0:continue
            modphi=s.Poly(phi,z,modulus=ell)
            common=s.gcd(modphi,s.Poly(f,z,modulus=ell))
            common=common.exquo(s.gcd(common,s.Poly(tau,z,modulus=ell)))
            if common.degree()<1:continue
            irreducible=s.factor_list(common)[1][0][0].monic()
            def coeff(poly):return [int(a)%ell for a in s.Poly(poly,z,modulus=ell).rem(irreducible).all_coeffs()]
            record={'n':n,'characteristic':ell,'field_degree':irreducible.degree(),
                    'field_polynomial':[int(a)%ell for a in irreducible.all_coeffs()],
                    'modes':ms,'p':coeff(p),'q':coeff(q),'tau':coeff(tau),'norm':norm}
            print(json.dumps(record),flush=True)
            Path(f'work/finite_extension_{n}.json').write_text(json.dumps(record,indent=2))
            return record
    print('NO HIT',n,'among',min(count+1,limit),'configurations',flush=True)

if __name__=='__main__':
    for n in map(int,sys.argv[1:]):search(n)
