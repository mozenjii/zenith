"""Verify every finite-field candidate exactly in Q[z]/Phi_n(z).

Requires Python 3.10+ and sympy. Compile exact_candidates.c first.
Example: python exact_search.py ./exact_candidates 9 420 --skip-covered
The sieve has no floating-point step. Its completeness proof is in the addendum.
"""
import argparse
import itertools
import json
import subprocess
from functools import lru_cache
from math import gcd, lcm
from pathlib import Path
import sympy as sp

Z = sp.Symbol('z')

@lru_cache(maxsize=None)
def field(n):
    return sp.Poly(sp.cyclotomic_poly(n, Z), Z, domain=sp.ZZ)

def exact_parameters(n, modes):
    """Return exact coefficient lists p,q,tau, or None for invalid/degenerate."""
    modulus = field(n)
    def reduce(poly):
        return poly.rem(modulus)
    cosines = [reduce(sp.Poly(Z**m + Z**(n-m), Z, domain=sp.ZZ)) for m in modes]
    zero = sp.Poly(0, Z, domain=sp.ZZ)
    e2 = reduce(sum((a*b for a,b in itertools.combinations(cosines, 2)), zero))
    if not reduce(e2+3).is_zero:
        return None
    p = -sum(cosines, zero)
    e3 = -sum((a*b*c for a,b,c in itertools.combinations(cosines,3)),zero)
    q = reduce(3*p+e3)
    e4 = reduce(cosines[0]*cosines[1]*cosines[2]*cosines[3])
    tau = reduce(p*q-e4)
    if tau.is_zero:
        return None
    return {key: [int(v) for v in reduce(value).all_coeffs()]
            for key,value in [('p',p),('q',q),('tau',tau)]}

def read_candidates(executable, lo, hi, skip=False):
    command=[str(Path(executable).resolve()), str(lo), str(hi)]
    if skip:
        command.append('skip-covered')
    result=subprocess.run(command, check=True, capture_output=True, text=True)
    return [(int(parts[0]),tuple(map(int,parts[1:])))
            for line in result.stdout.splitlines() if (parts:=line.split())]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('executable', type=Path)
    parser.add_argument('low', type=int)
    parser.add_argument('high', type=int)
    parser.add_argument('--skip-covered', action='store_true')
    parser.add_argument('--output', type=Path)
    args=parser.parse_args()
    candidates=read_candidates(args.executable,args.low,args.high,args.skip_covered)
    records=[]
    for n,modes in candidates:
        parameters=exact_parameters(n,modes)
        if parameters is not None:
            level=lcm(*(n//gcd(n,m) for m in modes))
            if level==n:
                records.append({'n':n,'modes':modes,**parameters})
    result={'low':args.low,'high':args.high,'skip_covered':args.skip_covered,
            'modular_candidates':len(candidates),
            'primitive_levels':sorted({r['n'] for r in records}),
            'primitive_certificates':records,
            'arithmetic':'integer modular sieve plus exact cyclotomic reduction'}
    rendered=json.dumps(result,indent=2)
    if args.output:
        args.output.write_text(rendered+'\n',encoding='utf-8')
    print(rendered)

if __name__=='__main__':
    main()
