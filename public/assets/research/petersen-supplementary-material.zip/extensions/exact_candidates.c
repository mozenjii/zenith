/* Exact finite-field necessary-condition sieve. No floating-point arithmetic.
   Compile: gcc -O3 -std=c11 exact_candidates.c -o exact_candidates
   Run: exact_candidates LOW HIGH [skip-covered]
   Emits n m1 m2 m3 m4; final cyclotomic verification is in exact_search.py. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int64_t I;
typedef struct { I value; int mode; } Entry;
static I mul(I a,I b,I p){return a*b%p;}
static I power(I a,I b,I p){I r=1;for(;b;b>>=1,a=mul(a,a,p))if(b&1)r=mul(r,a,p);return r;}
static int prime(I p){if(p<2)return 0;for(I d=2;d*d<=p;d++)if(p%d==0)return 0;return 1;}
static int compare(const void*a,const void*b){I x=((const Entry*)a)->value,y=((const Entry*)b)->value;return (x>y)-(x<y);}
static int lookup(Entry *a,int count,I v){int l=0,r=count;while(l<r){int m=(l+r)/2;if(a[m].value<v)l=m+1;else r=m;}return l<count&&a[l].value==v?a[l].mode:-1;}
static int order_n(I w,int n,I p){if(power(w,n,p)!=1)return 0;for(int d=2;d<=n;d++)if(n%d==0&&prime(d)&&power(w,n/d,p)==1)return 0;return 1;}

/* If the six roots of a triple form two complete cube-root orbits, its
   cosine values have sum 0 and e2=-3; adjoining any fourth gives tau=0. */
static int degenerate_triple(int a,int b,int c,int n){
    if(n%3)return 0;
    int s[6]={a,b,c,n-a,n-b,n-c};
    for(int i=0;i<6;i++){
        int target=(s[i]+n/3)%n,found=0;
        for(int j=0;j<6;j++)if(s[j]==target)found=1;
        if(!found)return 0;
    }
    return 1;
}
static void emit_candidate(int n,int i,int j,int k,int l){
    if(degenerate_triple(i,j,l,n)||degenerate_triple(i,k,l,n)||degenerate_triple(j,k,l,n))return;
    printf("%d %d %d %d %d\n",n,i,j,k,l);
}

static int search(int n){
    int count=(n-1)/2;
    I p=((1000000000LL+n-1)/n)*n+1;
    while(!prime(p))p+=n;
    I w=0;
    for(I a=2;!w;a++){I trial=power(a,(p-1)/n,p);if(order_n(trial,n,p))w=trial;}
    I *c=calloc(count+1,sizeof(I)),*prefix=calloc(count+2,sizeof(I)),*den=calloc(count+1,sizeof(I));
    Entry *sorted=calloc(count,sizeof(Entry));
    if(!c||!prefix||!den||!sorted){fprintf(stderr,"allocation failed\n");return 1;}
    for(int m=1;m<=count;m++){c[m]=(power(w,m,p)+power(w,n-m,p))%p;sorted[m-1]=(Entry){c[m],m};}
    qsort(sorted,count,sizeof(Entry),compare);
    for(int m=1;m<count;m++)if(sorted[m-1].value==sorted[m].value){fprintf(stderr,"noninjective embedding\n");return 1;}
    for(int i=1;i<=count-3;i++)for(int j=i+1;j<=count-2;j++){
        I s=(c[i]+c[j])%p, ab=mul(c[i],c[j],p);
        prefix[j+1]=1;
        for(int k=j+1;k<=count-1;k++){
            den[k]=(s+c[k])%p;
            prefix[k+1]=mul(prefix[k],den[k]?den[k]:1,p);
        }
        I inv=power(prefix[count],p-2,p);
        for(int k=count-1;k>=j+1;k--){
            I di=mul(inv,prefix[k],p);
            if(den[k])inv=mul(inv,den[k],p);
            I rhs=(p-(3+ab+mul(s,c[k],p))%p)%p;
            if(degenerate_triple(i,j,k,n))continue;
            if(den[k]){
                int l=lookup(sorted,count,mul(rhs,di,p));
                if(l>k)emit_candidate(n,i,j,k,l);
            }else if(rhs==0){
                for(int l=k+1;l<=count;l++)emit_candidate(n,i,j,k,l);
            }
        }
    }
    fprintf(stderr,"sieved n=%d prime=%lld\n",n,(long long)p);
    free(c);free(prefix);free(den);free(sorted);return 0;
}
int main(int argc,char **argv){
    if(argc<3||argc>4){fprintf(stderr,"usage: exact_candidates LOW HIGH [skip-covered]\n");return 2;}
    if(argc==4&&strcmp(argv[3],"skip-covered")){fprintf(stderr,"unknown option\n");return 2;}
    char *end1,*end2;long lo=strtol(argv[1],&end1,10),hi=strtol(argv[2],&end2,10);
    if(*end1||*end2||lo<7||hi<lo||hi>10000){fprintf(stderr,"require 7 <= LOW <= HIGH <= 10000\n");return 2;}
    for(int n=(int)lo;n<=hi;n++){
        if(argc==4&&(n%10==0||n%24==0||n%28==0||n%42==0))continue;
        if(search(n))return 1;
    }
    return 0;
}
