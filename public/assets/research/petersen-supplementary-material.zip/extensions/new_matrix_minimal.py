import sys,json
sys.path.insert(0,'work/python-packages')
import sympy as s
x=s.symbols('x'); data=json.load(open('work/new_matrix_results.json'));out={}
for a in data:
 R=s.Poly.from_list(a['c'][::-1],x,modulus=a['ell'])
 lev=next(k for k in s.divisors(a['n']) if s.rem(s.Poly(x**k-1,x,modulus=a['ell']),R).is_zero)
 if lev not in out:out[lev]=a
print(json.dumps(out,indent=2))
open('work/new_matrix_minimal.json','w').write(json.dumps(out,indent=2))
