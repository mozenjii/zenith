# Finite-field circulant certificates: checkpoint

Let F be any field; S the n-cycle shift. Put A=S+pI+bS^-1 and B=S^3+qI+dS^-3, with b,d,tau nonzero. Then H=[[A,I],[tau I,B]] has exactly the off-diagonal zero/nonzero pattern of P(n,3), n>=7. Elimination gives ker(H) isomorphic to ker(BA-tau I). Multiplication by invertible S^4 makes the latter R(S), where

R(z)=(z²+pz+b)(z⁶+qz³+d)-tau*z⁴.

As the cyclic shift is multiplication by z on F[z]/(z^n-1), nullity H = degree gcd(R,z^n-1). This remains true in inseparable characteristic: write R=gR1 and z^n-1=gh with gcd(R1,h)=1; the annihilated residues are exactly multiples of h, a space of dimension degree(g).

Zero forcing bounds the nullity of any such matrix over any field, without symmetry: a kernel vector zero on a forcing set is identically zero by applying each row equation at a forcing vertex. Therefore a degree8 gcd proves Z(P(n,3))>=8. This DOES NOT prove real symmetric maximum nullity8.

## Explicit exact certificates

1. n=16, F17: (p,b,q,d,tau)=(9,6,1,12,11).
R=z8+9z7+6z6+z5+15z4+6z3+12z2+6z+4.
Roots in F17: 2,3,5,7,8,9,12,13. All nonzero, distinct, so R divides z16-1.

2. n=18, F19: (p,b,q,d,tau)=(4,1,8,1,11).
R=z8+4z7+z6+8z5+2z4+8z3+z2+4z+1.
Roots in F19: 2,6,7,8,10,11,12,16. All nonzero, distinct, so R divides z18-1.
Here b=d=1, so left-scaling lower block rows by tau^-1 makes H symmetric while preserving its kernel and pattern.

These certificates imply Z>=8 for EVERY multiple of16 or18 respectively: R divides z^n-1 whenever16|n or18|n. Nullity remains exactly8 even when characteristic divides n, by the gcd theorem and degree8 bound. Combined with a separately established upperbound8, this proves equality Z=8 on these families.

Validation: work/new_matrix_verify.py prints exact polynomial division remainders zero and lists roots. Search script work/new_matrix_search.py enumerates degree8 monic divisors over prime fields and checks coefficient equations. Preliminary no prime-field examples at n13,14 through primes43; this is not an impossibility theorem, and extension fields remain possible.

## Extended exact search, completed

Additional primitive levels from the primefield search:
-17 overF2: p=1,b=1,q=0,d=1,tau=1. R=z8+z7+z6+z4+z2+z+1 divides z17-1. This is symmetric and has binary coefficients.
-22 overF23: p=8,b=1,q=21,d=1,tau=14.
-26 overF5: p=2,b=1,q=4,d=1,tau=2.
-38 overF7: p=0,b=5,q=0,d=3,tau=3.
Also redundant levels32 and36 found; their multiples already covered by16 and18.

All records are in new_matrix_minimal.json; no primefield certificate for13,14,27 through primes43, but this is a bounded search only. Search stops at first successful characteristic for each n, not a full classification.

Independent validation with direct Gaussian elimination on actual2n-by2n matrices (standard Python only): new_matrix_direct_validation.py. All16 tested matrices, at each found minimallevel and its double, have exactly three nonzero offdiagonal entries in everyrow and exactnullity8. Includes n34 characteristic2 (inseparable z34-1), confirming the repeatedroot gcd case. Exact symbolic checks in new_matrix_minimal.py establish R divisibility, sufficient for infinitefamilies.
