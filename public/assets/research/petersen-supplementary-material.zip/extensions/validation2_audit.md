# Validation audit, 6 September 2026

## Reproduced original work

The original supplementary validation code was actually rerun, not replaced with a new theoretical assertion.

- verify_paper.py: all 18 symbolic checks pass (validation2_symbolic.txt).
- classify_rational.py: all 14 candidates, eight degenerate and six valid, reproduced; primitive rational levels 10,24,40,42 (validation2_rational.txt).
- Original zero_forcing.c compiled with GCC -O3 and rerun for every n=7..27, k=3, rmax=8. Every supplied output is reproduced exactly (validation2_zero_forcing_7_20.txt and validation2_zero_forcing_21_27.txt). Runtime approximately ten seconds total on this host.
- Independently implemented set-based forcing closure in validation2_witnesses.py checks all 21 supplied witnesses. The independent checker confirms upper bounds only. Exhaustive C reproduction supplies the lower bounds for the finite range.

The reproduced zero forcing values are 6 for n=7,8,9; 8 for n=10; 7 for n=11,12; and 8 for every n=13..27.

## Mathematically consequential scope limits

1. The floating-point search_moduli.py is not a completeness proof. It filters both candidate fourth modes and tau using tolerances. A true solution can be missed. Its docstring and printed warning correctly disclose this. Exact checking of retained hits makes positives reliable; it does not make negative results reliable. The later exact_candidates.c plus exact_search.py addresses this issue through the claimed finite search range.
2. Symbolic identity checks verify displayed algebra, not every statement in the manuscript. In particular the modulus-28 factorization modulo the minimal polynomial verifies a polynomial identity, but the roots' required root-of-unity orders must also be justified mathematically. The rational candidate list relies on the proof's exhaustive totient bound rather than verifying that bound itself.
3. Finite computation through n=27 cannot prove the conjecture for all n. Checking a forcing witness alone supplies an upper bound, never its minimality.
4. A finite-field matrix certificate must retain NONZERO values at every graph edge, and zero at every off-diagonal nonedge. Rank drops caused by deleting an edge modulo a prime are invalid certificates for the same graph.
5. A valid finite-field certificate proves a lower bound on Z over the graph, but does not automatically prove the real maximum-nullity lower bound.

## Why the finite-field route is legitimate for Z

Let F be any field and A a matrix whose off-diagonal nonzero pattern is exactly G. Let B be a zero forcing set. If x lies in ker(A) and vanishes on B, a forcing move i->j has all neighbors of i except j already known zero. Row i of Ax=0 reduces to a_ij x_j=0: the diagonal term is zero because x_i=0. Since a_ij is nonzero in the field, x_j=0. Induction forces x=0. Thus restriction ker(A)->F^B is injective, and nullity_F(A)<=|B|. In particular nullity_F(A)<=Z(G).

Consequently an exact nullity-eight matrix over F_p combined with a size-eight forcing set proves Z(G)=8. It need not prove M_R(G)=8. If an integer matrix has rank r modulo p, then its rational/real rank is at least r; modular rank deficiency may disappear in characteristic zero. This is precisely why the new field route can address the zero forcing half separately.

## Original zero_forcing.c robustness findings

These do not invalidate the reproduced valid-input results.

- It accesses argv[1..3] without checking argc. Missing arguments may crash.
- atoi silently accepts malformed input and offers no overflow handling.
- Negative n/k and k=0 are not rejected; the code can form invalid shifts/graphs.
- idx[16] means rmax>16 can overflow the stack buffer. r>N2 is also unsafe.
- The graph size condition computes 2*n before checking, so oversized parsed inputs may overflow. The loop bound may overflow too.
- The existing guard safely skips n>32 for normal positive inputs. It does NOT provide a >64-vertex solver. Extending this needs a dynamic bitset or a different representation, not removing the guard.

A robust CLI should first require 4 or 5 arguments, parse with strtol and full errno/end-pointer checks, require 3<=nlo<=nhi<=32, 1<=k and 2*k<nlo, and 1<=rmax<=min(16,2*nlo). Reject the full request explicitly rather than silently skipping unsupported sizes. Alternatively increase idx to 64 and cap rmax at the smallest graph order. None of the original source files were modified.

## Prior exact search audit

Inspected outputs/exact_candidates.c and exact_search.py. The modular fourth-mode equation covers the zero-denominator case explicitly. Injectivity of finite-field cosine values is checked. Discarded cube-orbit triples are algebraically tau=0, hence legitimate exclusions. Exact cyclotomic verification follows the sieve; the small exhaustive comparison test checks retained true solutions. This is a finite classification of constant-weight mode certificates, not all weighted matrices nor a global graph-conjecture proof.
