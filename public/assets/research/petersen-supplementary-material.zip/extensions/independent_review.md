# Independent mathematical and implementation audit

Reviewed 2026-09-08: `work/new_matrix_checkpoint.md`, `work/direct_zf_anchoring.md`, and `work/direct_zf_anchor.c`. This is an independent AI review, not external peer review or a literature novelty assessment.

## Verdict

No mathematical correctness defect found in the arbitrary-field certificate theorem, its use with nonsymmetric graph-pattern matrices, the inseparable gcd argument, or the first-force anchoring reduction. No correctness or memory-safety defect found for the documented C program calls. The finite-field results imply zero-forcing lower bounds, not real symmetric maximum-nullity lower bounds.

## Certificate proof

For a matrix H over any field whose off-diagonal entry H_xy is nonzero exactly when x and y are adjacent, restriction from ker(H) to the coordinates of a zero-forcing set B is injective. Indeed, a kernel vector vanishing on B remains zero at every forced vertex: at a blue forcing vertex x, every term of row x is already zero except possibly the unique white neighbor y, and H_xy is nonzero. This argument requires neither symmetry nor characteristic zero. Rank-nullity of the restriction gives nullity(H) <= |B|.

For n >= 7 the shift powers in A=S+pI+bS^-1 and B=S^3+qI+dS^-3 give exactly the required three off-diagonal entries per row of H=[[A,I],[tau I,B]], provided b,d,tau are nonzero. The first block row determines y=-Ax, and the second becomes (BA-tau I)x=0. All blocks are polynomials in S, so multiplying by S^4 gives the stated polynomial R(S). R is monic of degree eight.

The cyclic module argument is valid without squarefreeness. Put f=z^n-1, g=gcd(R,f), R=gR1, and f=gh. After cancellation in the polynomial ring, f divides Ra exactly when h divides R1*a. Since gcd(R1,h)=1, this holds exactly when h divides a. Multiples of h modulo f form a vector space of dimension deg(g). Thus nullity(H)=deg(g) also when the characteristic divides n. If R divides z^L-1 and L divides n, then R divides z^n-1 and nullity is exactly eight. Combined with the established upper bound, this proves Z=8.

When b=d=1, left multiplication by diag(I,tau^-1 I) makes H symmetric over its field. It does not turn it into a real matrix certificate.

This audit concerns the theorem and implementation; the complete expanded table of certificate coefficients should still be verified by exact polynomial division and direct modular matrix ranks in the final validation suite.

## Anchoring and exhaustive search

The four seeds exhaust first-force types under rotations and reflection: outer or inner forcing vertex, followed by a spoke or same-layer force. Enlarging a forcing set to size r preserves zero forcing. Since r < 2n, a successful set has a first force, making the argument applicable. The converse is immediate. The candidate count is at most 4*C(2n-3,r-3), including harmless overlap. For r=7 this is O(n^4).

The C graph construction matches P(n,3), including n=7 and n=64. All shifts remain within indices 0..127; the special full-mask case avoids a shift by 128. The low-bit helper is invoked only for nonzero masks. Combination enumeration covers every completion once per seed, and all actual callers keep its indices within its fixed arrays.

The queue closure is complete: a previously disabled blue vertex can become able to force only after a neighboring white vertex becomes blue, and that transition checks and queues it. Each vertex is queued once when initially or newly blue, and at most once more when its white-neighbor count decreases to one. Consequently at most 2*(2n) <= 256 queue entries occur; capacity 512 suffices. Duplicate processing is harmless. This gives linear closure time on the cubic graph and O(n^5) total search time.

## Executed verification

- Independently compiled the C source with GCC using `-std=c11 -O2 -Wall -Wextra -Wconversion`; no diagnostics.
- Independently reran `work/review_direct_zf.exe 7 12 selftest`; every level passed. This checks 30 anchored-versus-unrestricted decisions and queue-versus-rescan closure on all 344,064 subsets for n=7,8,9.
- Inspected both saved range logs: every n=13..64 reports no size-seven forcing set and a successful size-eight witness. These full range computations were not independently rerun in this audit.

## Minor usability issue

Any fourth CLI argument activates self-test mode, although the usage message names `selftest`. This does not affect the documented runs or their correctness. Optionally require the literal `selftest` to avoid an accidental very long unrestricted run caused by a typo. No manuscript theorem depends on this change.

The finite computations do not prove the conjecture for every n, and this review makes no claim that these methods or families are new to the literature.
