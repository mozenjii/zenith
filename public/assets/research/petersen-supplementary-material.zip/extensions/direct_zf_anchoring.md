# Direct zero-forcing extension: first-force anchoring

Status: proved search reduction; no uniform lower bound claimed. This is a direct combinatorial route independent of constant-weight Fourier certificates. Novelty relative to published algorithms has not been established.

Let P(n,3), n>=7, have outer u_i, inner v_i, with usual edges u_i u_(i+1), u_i v_i, v_i v_(i+3). For any target r<2n with r>=3, a zero forcing set of size at most r exists if and only if a size-r zero forcing set exists containing one of:

A = {u_0,u_(n-1),u_1};
B = {u_0,u_1,v_0};
C = {v_0,v_(n-3),v_3};
D = {v_0,v_3,u_0}.

Proof. Enlarge any set of size at most r to size r; zero forcing is monotone. Its first force x->y requires x and its two neighbors other than y initially blue. Rotation moves x to index zero. If x is outer, y is either its spoke neighbor (A) or an outer neighbor; reflection handles the two directions (B). If x is inner, y is either its spoke neighbor (C) or an inner neighbor, again reflected to the chosen direction (D). Rotations and reflection preserve all edges, hence preserve zero forcing. Conversely each searched set is an actual r-set. This is an exhaustive equivalence, not heuristic symmetry pruning.

For r=7 there are at most 4 binomial(2n-3,4) tested sets rather than binomial(2n,7). The ratio of original to new candidate counts is (2n)(2n-1)(2n-2)/840, already 70.6 at n=20 and 586.9 at n=40. Overlap among anchors is harmless. The resulting candidate count is O(n^4), and a queue closure is O(n), giving O(n^5) total time and O(n) working space. A simple rescan closure has a weaker worst-case runtime but preserves correctness.

This offers a practical extension of the supplied zero_forcing.c validator beyond its 64-bit n<=32 ceiling. A finite search cannot prove the uniform conjecture. For a proof-oriented use, collect terminal white sets (forts) for the four anchored four-vertex completions and seek a finite family of gap-dependent templates. Every failed closure produces a fort F: each vertex outside F has zero or at least two neighbors in F. A successful proof would need to cover all cyclic gap lengths, not just a tested range.

Validation plan: compare anchored and unrestricted enumeration for all n=7..12 and r=3..7, check positive witnesses directly, then run n>=13 at r=7 plus verify the known eight consecutive outer vertices as an upper-bound witness for each tested n. The prototype only supports n<=64 by using 128-bit masks and explicitly rejects invalid arguments.


Completed validation (2026-09-06):
- Anchored and unrestricted enumeration agree for every n=7..12 and r=3..7 (30 decisions).
- Queue closure agrees with independent direct-rescan closure on EVERY blue subset for n=7,8,9 (344,064 subsets total).
- Exact anchored r=7 enumeration for EVERY n=13..64 found no seven-vertex zero forcing set. All tested n also accepted the eight consecutive outer vertices witness. Hence the computation certifies Z(P(n,3))=8 throughout 13<=n<=64, conditional only on ordinary executable correctness; it does NOT establish maximum nullity on all those levels.
- Logs: direct_zf_selftest.txt, direct_zf_results_13_40.txt, direct_zf_results_41_64.txt.
- Build: gcc -std=c11 -O3 -Wall -Wextra work/direct_zf_anchor.c -o work/direct_zf_anchor.exe
- Selftest: work/direct_zf_anchor.exe 7 12 selftest
- Range run: work/direct_zf_anchor.exe 13 64

Implementation uses a bounded event queue. Initially each blue vertex is queued. When a newly blue y appears, y is queued and each blue neighbor z with exactly one remaining white neighbor is queued. This is complete since only a neighbor changing white->blue can enable a previously disabled blue z. Such an enabling event occurs at most once per z (white-neighbor count decreases monotonically); initial and newly-blue vertex queueing occurs at most once per vertex. Therefore at most 2*(2n)<=256 queue entries occur, within the allocated capacity 512. Repeated processing is harmless. This proves linear queue closure time on these cubic graphs.
