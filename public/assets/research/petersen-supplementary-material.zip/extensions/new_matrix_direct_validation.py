import json

def rank_mod(matrix,ell):
    a=[row[:] for row in matrix];rank=0
    for j in range(len(a[0])):
        pivot=next((i for i in range(rank,len(a)) if a[i][j]%ell),None)
        if pivot is None:continue
        a[rank],a[pivot]=a[pivot],a[rank]
        inv=pow(a[rank][j],-1,ell)
        a[rank]=[v*inv%ell for v in a[rank]]
        for i in range(rank+1,len(a)):
            scale=a[i][j]%ell
            if scale:a[i]=[(v-scale*w)%ell for v,w in zip(a[i],a[rank])]
        rank+=1
    return rank

def matrix(n,p,b,q,d,t):
    rows=[]
    for i in range(2*n):
        row=[0]*(2*n)
        if i<n:
            row[i]=p;row[(i+1)%n]=1;row[(i-1)%n]=b;row[n+i]=1
        else:
            k=i-n;row[i]=q;row[n+(k+3)%n]=1;row[n+(k-3)%n]=d;row[k]=t
        rows.append(row)
    return rows

if __name__=='__main__':
    data=json.load(open('work/new_matrix_minimal.json'))
    for ns,a in data.items():
        for n in (int(ns),2*int(ns)):
            h=matrix(n,a['p'],a['b'],a['q'],a['d'],a['tau'])
            assert all(sum(v%a['ell']!=0 for j,v in enumerate(row) if i!=j)==3 for i,row in enumerate(h))
            nullity=2*n-rank_mod(h,a['ell'])
            assert nullity==8,(n,a,nullity)
            print(f'n={n}, field={a["ell"]}, nullity={nullity}, pattern OK')
