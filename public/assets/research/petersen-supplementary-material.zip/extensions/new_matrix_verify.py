import sys
sys.path.insert(0,'work/python-packages')
import sympy as s
x=s.symbols('x')
for n,l,p,b,q,d,t in [(16,17,9,6,1,12,11),(18,19,4,1,8,1,11)]:
 R=s.Poly((x*x+p*x+b)*(x**6+q*x**3+d)-t*x**4,x,modulus=l)
 quo,rem=s.div(s.Poly(x**n-1,x,modulus=l),R)
 print(n,l,'R=',R.as_expr(),'quotient=',quo.as_expr(),'remainder=',rem.as_expr())
 print('roots',[i for i in range(l) if R.eval(i)%l==0])
