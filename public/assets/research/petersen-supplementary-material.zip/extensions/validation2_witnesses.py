"""Independently check the supplied zero-forcing witnesses (not minimality).
Usage: python validation2_witnesses.py PATH_TO_zero_forcing_7_27.txt
Uses Python sets, independently of the original C bitset implementation.
"""
import sys
from pathlib import Path


def closure(n, k, blue):
    if not (n >= 3 and 1 <= k and 2*k < n):
        raise ValueError('require n >= 3 and 1 <= k < n/2')
    edges = tuple(frozenset(((i-1)%n, (i+1)%n, n+i)) for i in range(n)) + tuple(
        frozenset((i, n+(i-k)%n, n+(i+k)%n)) for i in range(n))
    blue = frozenset(blue)
    if not blue <= frozenset(range(2*n)):
        raise ValueError('vertex outside graph')
    while True:
        newly = frozenset(w for b in blue for w in edges[b]-blue
                          if len(edges[b]-blue) == 1)
        if not newly:
            return blue
        blue = blue | newly


def check(path):
    checked = 0
    for line in Path(path).read_text(encoding='utf-8-sig').splitlines():
        parts = line.split()
        if not parts or not parts[0].isdigit():
            continue
        n, size = map(int, parts[:2])
        vertices = tuple(int(s[1:]) + (n if s[0] == 'v' else 0)
                         for s in parts[2:])
        assert len(vertices) == len(set(vertices)) == size
        assert closure(n, 3, vertices) == frozenset(range(2*n)), n
        checked += 1
    assert checked > 0
    print(f'PASS: {checked} supplied witnesses force independently; this checks upper bounds only.')


if __name__ == '__main__':
    check(sys.argv[1])
