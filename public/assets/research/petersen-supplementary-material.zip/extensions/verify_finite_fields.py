"""Exact polynomial and independent graph-matrix validation (Python + SymPy)."""
import json
from pathlib import Path
import sympy as sp

# L, characteristic, p, b, q, d, tau; corrected base levels.
ROWS = [
    (16,17,9,6,1,12,11), (17,2,1,1,0,1,1),
    (18,19,4,1,8,1,11), (19,229,15,1,12,1,84),
    (21,41,28,1,22,1,33), (22,23,8,1,21,1,14),
    (23,461,111,1,234,1,146), (25,499,364,1,355,1,26),
    (26,5,2,1,4,1,2), (27,271,45,1,230,1,181),
    (29,233,46,1,188,1,61), (31,743,619,1,574,1,699),
    (38,7,0,5,0,3,3),
]

def rank_mod(matrix, ell):
    a = [row[:] for row in matrix]
    rank = 0
    for col in range(len(a[0])):
        pivot = next((i for i in range(rank,len(a)) if a[i][col]), None)
        if pivot is None:
            continue
        a[rank], a[pivot] = a[pivot], a[rank]
        inv = pow(a[rank][col], -1, ell)
        a[rank] = [(x*inv)%ell for x in a[rank]]
        for i in range(rank+1,len(a)):
            factor = a[i][col]
            if factor:
                a[i] = [(x-factor*y)%ell for x,y in zip(a[i],a[rank])]
        rank += 1
    return rank

def matrix_for(n, ell, p, b, q, d, tau):
    a = [[0]*(2*n) for _ in range(2*n)]
    for i in range(n):
        for j,w in [(i,p),((i+1)%n,1),((i-1)%n,b),(n+i,1)]:
            a[i][j] = w%ell
        for j,w in [(n+i,q),(n+(i+3)%n,1),(n+(i-3)%n,d),(i,tau)]:
            a[n+i][j] = w%ell
    for i in range(2*n):
        j = i%n
        expected = ({(j+1)%n,(j-1)%n,n+j} if i<n else
                    {n+(j+3)%n,n+(j-3)%n,j})
        assert {k for k in range(2*n) if k!=i and a[i][k]} == expected
    return a

def main():
    z = sp.Symbol('z')
    results = []
    for L,ell,p,b,q,d,tau in ROWS:
        assert sp.isprime(ell) and all(x%ell for x in (b,d,tau))
        R = sp.Poly((z*z+p*z+b)*(z**6+q*z**3+d)-tau*z**4,z,modulus=ell)
        quotient, remainder = sp.div(sp.Poly(z**L-1,z,modulus=ell),R)
        assert remainder.is_zero
        checks = []
        levels = sorted({L,2*L} | ({ell*L} if ell in (2,5,7) else set()))
        for n in levels:
            predicted = sp.gcd(R,sp.Poly(z**n-1,z,modulus=ell)).degree()
            actual = 2*n-rank_mod(matrix_for(n,ell,p,b,q,d,tau),ell)
            assert actual == predicted == 8, (L,ell,n,actual)
            checks.append({'n':n,'nullity':actual,'inseparable':n%ell==0})
        results.append(dict(L=L,characteristic=ell,p=p,b=b,q=q,d=d,tau=tau,
                            quotient_descending=[int(x)%ell for x in quotient.all_coeffs()],
                            direct_rank_checks=checks))
        print(f'PASS L={L}, F_{ell}: exact division, exact graph pattern, ranks {levels}',flush=True)
    out = Path(__file__).with_name('finite_field_validation.json')
    out.write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(f'PASS all {len(results)} certificates; saved {out.name}')

if __name__ == '__main__':
    main()
