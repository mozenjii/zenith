import sympy as s,itertools,json
x=s.symbols('x')
results=[]
for n in [13,14,16,18,22,26,27,32,34,36,38]:
 for ell in list(s.primerange(2,44)):
  fac=s.factor_list(x**n-1,modulus=ell)[1]
  ds=[(s.Poly(1,x,modulus=ell),0)]
  for f,e in fac:
   f=s.Poly(f,x,modulus=ell); new=[]
   for a,deg in ds:
    for k in range(min(e,(8-deg)//f.degree())+1):new.append((a*f**k,deg+k*f.degree()))
   ds=new
  for a,deg in ds:
   if deg!=8:continue
   c=[int(a.nth(i))%ell for i in range(9)]
   p,b,q,d=c[7],c[6],c[5],c[2]
   tau=(p*q-c[4])%ell
   if b*d*tau%ell and c[3]==b*q%ell and c[1]==p*d%ell and c[0]==b*d%ell:
    r=dict(n=n,ell=ell,p=p,b=b,q=q,d=d,tau=tau,c=c);results.append(r);print(r,flush=True)
  if any(r['n']==n for r in results):break
 print('done',n,flush=True)
open('work/new_matrix_results.json','w').write(json.dumps(results,indent=2))
