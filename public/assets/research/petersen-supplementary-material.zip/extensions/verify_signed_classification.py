"""Exact finite algebra for the Q_k classification; requires SymPy."""
import sympy as s

z = s.symbols('z')
ORDERS = (1, 2, 3, 4, 5, 6, 8, 10, 12, 24)
EXPECTED = {5: (2, 3), 6: (2, 4), 10: (3, 7), 24: (7, 17)}

def q(k):
    return s.Poly(z**(2*k+2) + z**(2*k) + z**(k+1) + z**2 + 1, z, domain=s.ZZ)

for n in ORDERS:
    phi = s.Poly(s.cyclotomic_poly(n, z), z, domain=s.ZZ)
    residues = tuple(k for k in range(n) if q(k).rem(phi).is_zero)
    assert residues == EXPECTED.get(n, ()), (n, residues)
    print(f'Phi_{n}: residues {residues} modulo {n}')

for k, factors in ((2, (5, 6)), (3, (5, 10)), (7, (5, 10, 24))):
    product = s.Poly(s.prod(s.cyclotomic_poly(n, z) for n in factors), z)
    assert q(k) == product
    assert s.gcd(q(k), q(k).diff()).degree() == 0
    print(f'Q_{k}: exact squarefree factorization {factors}')
print('All finite algebraic steps pass. Global bound is proved in Research_Addendum.tex.')

# A repeated nonzero root of Q is a zero of D=z*d(z^(-k-1)Q)/dz.
K = s.symbols('K')
for n, residues in EXPECTED.items():
    for r in residues:
        d = ((K+1)*(z**((r+1)%n)-z**((-r-1)%n))
             + (K-1)*(z**((r-1)%n)-z**((1-r)%n)))
        remainder = s.Poly(s.rem(d, s.cyclotomic_poly(n,z), z),z)
        if n in (5,10):
            assert remainder.coeff_monomial(z**2) == -2
        elif n == 6:
            expected = (K-1)*(2*z-1) if r == 2 else -(K+1)*(2*z-1)
            assert s.expand(remainder.as_expr()-expected) == 0
        else:
            assert s.solve([remainder.coeff_monomial(z**6),
                            remainder.coeff_monomial(z**4)],K) == []
print('All cyclotomic simplicity calculations pass.')
