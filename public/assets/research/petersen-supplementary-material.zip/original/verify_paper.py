"""Exact/symbolic checks for the manuscript's displayed algebraic identities."""
from math import gcd
from functools import reduce
import sympy as sp

z, p, q, tau = sp.symbols("z p q tau")
alpha = sp.symbols("alpha")
R = z**8 + p*z**7 + z**6 + q*z**5 + (p*q-tau)*z**4 + q*z**3 + z**2 + p*z + 1

def Phi(m):
    return sp.cyclotomic_poly(m, z)

def lcm(a,b):
    return a*b//gcd(a,b)

def lcmm(xs):
    return reduce(lcm, xs, 1)

def ok(label, cond):
    if not cond:
        raise AssertionError(label)
    print(f"PASS  {label}")

# Determinant identity for normalized blocks.
eps = sp.symbols("eps", nonzero=True)
det_block = eps*((p+z+z**-1)*(q+z**3+z**-3)-tau)
ok("normalized Fourier determinant", sp.simplify(z**4*det_block/eps-R) == 0)

# Normalization of a general constant-weight block-circulant determinant.
a,b,c,d,e,x,y = sp.symbols("a b c d e x y", nonzero=True)
pn, qn, tn = d/a, e/c, b**2/(a*c)
general = (d+a*x)*(e+c*y)-b**2
normalized = a*c*((pn+x)*(qn+y)-tn)
ok("general constant-weight normalization", sp.simplify(general-normalized) == 0)

# Mode-selection expansion.
a1,a2,a3,a4 = sp.symbols("a1 a2 a3 a4")
A=[a1,a2,a3,a4]
e1=sum(A)
e2=sum(A[i]*A[j] for i in range(4) for j in range(i+1,4))
e3=sum(A[i]*A[j]*A[k] for i in range(4) for j in range(i+1,4) for k in range(j+1,4))
e4=sp.prod(A)
prod=sp.expand(sp.prod(z**2+ai*z+1 for ai in A))
claimed=(z**8+e1*z**7+(4+e2)*z**6+(3*e1+e3)*z**5+(6+2*e2+e4)*z**4
         +(3*e1+e3)*z**3+(4+e2)*z**2+e1*z+1)
ok("mode-selection polynomial expansion", sp.expand(prod-claimed)==0)
# Difference after substituting p,q,tau is a multiple of e2+3.
Rsel=sp.expand(R.subs({p:e1,q:3*e1+e3,tau:e1*(3*e1+e3)-e4}))
diff=sp.Poly(sp.expand(claimed-Rsel), z)
ok("mode-selection reduction under e2=-3",
   all(sp.rem(sp.Poly(co, a4), sp.Poly(e2+3, a4)).is_zero for co in diff.all_coeffs()))

# Reflection identity.
ok("reflection R_pqt(-z)=R_-p,-q,tau(z)",
   sp.expand(R.subs(z,-z)-R.subs({p:-p,q:-q}))==0)

# Rational table.
table=[(10,(0,0,-1),[5,10]),(24,(0,0,-2),[3,6,8]),
       (40,(1,1,-1),[5,8]),(42,(0,1,-1),[6,7])]
for L,(pp,qq,tt),fs in table:
    rv=sp.expand(R.subs({p:pp,q:qq,tau:tt}))
    pv=sp.expand(sp.prod(Phi(m) for m in fs))
    ok(f"rational certificate L={L}", rv==pv and sp.gcd(rv,sp.diff(rv,z))==1 and lcmm(fs)==L and tt!=0)

# Modulus 28 identity, exact modulo minimal polynomial of alpha.
minpoly=sp.Poly(alpha**3-alpha**2-2*alpha+1,alpha)
R28=sp.expand(R.subs({p:1-alpha**2,q:alpha,tau:-1}))
F1=z**4-alpha*z**2+1
F2=z**4+(1-alpha**2)*z**3+(alpha+1)*z**2+(1-alpha**2)*z+1
coef_diff=sp.Poly(sp.expand(R28-F1*F2),z).all_coeffs()
ok("modulus-28 factorization modulo minpoly(alpha)",
   all(sp.rem(sp.Poly(co,alpha),minpoly).is_zero for co in coef_diff))

# Density counts by one full period, avoiding hand arithmetic.
def density_count(moduli):
    L=lcmm(moduli)
    hits=sum(any(r%m==0 for m in moduli) for r in range(L))
    return hits,L
ok("coverage density = 1/6", density_count([10,24,28,42])==(140,840))
ok("rational coverage density = 31/210", density_count([10,24,42])==(124,840))

# Signed Q_k factorizations and determinant identity.
for kk,fs,L in [(2,[5,6],30),(3,[5,10],10),(7,[5,10,24],120)]:
    Q=z**(2*kk+2)+z**(2*kk)+z**(kk+1)+z**2+1
    det=-(z+z**-1)*(z**kk+z**(-kk))-1
    ok(f"signed determinant identity k={kk}", sp.simplify(det+z**(-(kk+1))*Q)==0)
    ok(f"Q_{kk} cyclotomic factorization", sp.expand(Q-sp.prod(Phi(m) for m in fs))==0 and lcmm(fs)==L)

print("\nALL SYMBOLIC CHECKS PASSED")
