"""Exact finite enumeration used in the rational-certificate classification."""
import itertools
import sympy as sp
z=sp.symbols('z')
# All m>=3 satisfying phi(m)<=8 (listed explicitly in the proof).
cand=[3,4,6,5,8,10,12,7,9,14,18,15,16,20,24,30]
res=[]
for r in range(1,5):
    for S in itertools.combinations(cand,r):
        if sum(int(sp.totient(m)) for m in S)!=8:
            continue
        P=sp.Poly(sp.expand(sp.prod(sp.cyclotomic_poly(m,z) for m in S)),z)
        c=P.all_coeffs()
        if len(c)!=9 or c[0]!=1 or c[-1]!=1 or c[2]!=1 or c[6]!=1:
            continue
        p,q=c[1],c[3]
        if c[5]!=q or c[7]!=p:
            continue
        tau=p*q-c[4]
        L=int(sp.ilcm(*S)) if len(S)>1 else S[0]
        res.append((S,int(p),int(q),int(tau),L))

assert len(res)==14
valid=[x for x in res if x[3]!=0]
assert len(valid)==6
assert {x[4] for x in valid}=={10,24,40,42}
print("All degree-8 products of distinct cyclotomic polynomials with [z^6]=[z^2]=1")
print(f"{'factors':24} {'p':>3} {'q':>3} {'tau':>4} {'L':>4}  status")
for S,p,q,t,L in sorted(res,key=lambda x:(x[4],x[0])):
    factors='*'.join('Phi'+str(m) for m in S)
    status='VALID' if t else 'degenerate (tau=0)'
    print(f"{factors:24} {p:3d} {q:3d} {t:4d} {L:4d}  {status}")
print("\nVALID rational moduli:",sorted({x[4] for x in valid}))
print("RATIONAL CLASSIFICATION CHECK PASSED")
