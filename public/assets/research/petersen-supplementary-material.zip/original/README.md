# Supplementary computational material

This directory accompanies **Weighted Fourier certificates for maximum nullity in generalized Petersen graphs: rational classification and arithmetic obstructions** by Mohib Ahmad.

## Files

- `verify_paper.py` — symbolic checks of the determinant identities, normalization, mode-selection expansion, reflection symmetry, four rational certificates, the modulus-28 identity, density counts, and signed `Q_k` certificates.
- `classify_rational.py` — exact finite enumeration used in the proof of the complete classification over `Q`.
- `search_moduli.py` — computer-assisted search for primitive algebraic certificate levels. Candidate generation uses floating point; every positive hit is verified exactly in `Z[zeta_n]`. **The absence of a hit is not used as a proof of nonexistence.**
- `zero_forcing.c` — exact exhaustive search of vertex subsets for the zero forcing numbers in the finite range reported in the paper.
- `outputs/` — recorded outputs from the commands below.

## Reproduce

Python 3 with SymPy and NumPy is required. GCC or another C11 compiler is needed for the zero-forcing program.

```bash
python verify_paper.py
python classify_rational.py
python search_moduli.py 9 140
python search_moduli.py 9 420 --skip-covered
gcc -O3 -std=c11 -o zero_forcing zero_forcing.c
./zero_forcing 7 27 3 9
```

The `9..140` search should report primitive levels `10, 24, 28, 40, 42, 60, 84`. The `--skip-covered` run through `420` should report no new primitive level after excluding multiples of `10,24,28,42`.

The zero-forcing code uses a 64-bit bitset and therefore requires `2n <= 64`.
