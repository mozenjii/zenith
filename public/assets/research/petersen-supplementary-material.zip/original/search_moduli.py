"""Computer-assisted search for primitive root-of-unity certificates.

This is deliberately NOT used as a nonexistence proof in the manuscript.
A floating-point screen proposes fourth modes; every reported positive hit is
then verified exactly in Z[zeta_n] by reduction modulo Phi_n.
"""
import argparse,itertools,math
import numpy as np
from sympy import cyclotomic_poly,Poly,ZZ,symbols
z=symbols('z'); _pc={}
def phi(n):
    if n not in _pc: _pc[n]=Poly(cyclotomic_poly(n,z),z,domain=ZZ)
    return _pc[n]
def iszero(v,n):
    if not any(v): return True
    return Poly(list(reversed([int(x) for x in v])),z,domain=ZZ).rem(phi(n)).is_zero
def cvec(m,n):
    v=[0]*n; v[m%n]+=1; v[-m%n]+=1; return v
def mul(a,b,n):
    o=[0]*n
    for i,ai in enumerate(a):
        if ai:
            for j,bj in enumerate(b):
                if bj:o[(i+j)%n]+=ai*bj
    return o
def add(a,b):return [x+y for x,y in zip(a,b)]
def scal(a,s):return [s*x for x in a]
def exact_ok(n,modes):
    cs=[cvec(m,n) for m in modes]; e2=[0]*n
    for i,j in itertools.combinations(range(4),2): e2=add(e2,mul(cs[i],cs[j],n))
    t=e2[:];t[0]+=3
    if not iszero(t,n):return False
    aa=[scal(x,-1) for x in cs];E1=[0]*n;E3=[0]*n
    for x in aa:E1=add(E1,x)
    for i,j,k in itertools.combinations(range(4),3):E3=add(E3,mul(mul(aa[i],aa[j],n),aa[k],n))
    E4=mul(mul(aa[0],aa[1],n),mul(aa[2],aa[3],n),n)
    Q=add(scal(E1,3),E3);TAU=add(mul(E1,Q,n),scal(E4,-1))
    return not iszero(TAU,n)
def primitive_level(n,modes):
    L=1
    for m in modes:
        o=n//math.gcd(n,m);L=math.lcm(L,o)
    return L

def search_one(n):
    M=(n+1)//2;ms=np.arange(1,M,dtype=int)
    if len(ms)<4:return []
    c=2*np.cos(2*np.pi*ms/n); order=np.argsort(c); cs=c[order]
    pairs=np.array(list(itertools.combinations(range(len(ms)),2)),dtype=np.int32)
    candidates=set()
    for i in range(len(ms)-2):
        sel=pairs[pairs[:,0]>i]
        if not len(sel):continue
        cj,ck=c[sel[:,0]],c[sel[:,1]]
        S3=c[i]+cj+ck;e23=c[i]*cj+c[i]*ck+cj*ck
        gen=np.abs(S3)>1e-9
        need=np.full(S3.shape,np.inf);need[gen]=(-3.0-e23[gen])/S3[gen]
        idx=np.searchsorted(cs,need)
        for shift in (-1,0,1):
            jj=np.clip(idx+shift,0,len(cs)-1)
            close=gen&(np.abs(cs[jj]-need)<1e-8)
            for t in np.nonzero(close)[0]:
                m4=int(ms[order[jj[t]]]); tri=[int(ms[i]),int(ms[sel[t,0]]),int(ms[sel[t,1]])]
                if m4 not in tri:candidates.add(tuple(sorted(tri+[m4])))
        degen=(~gen)&(np.abs(e23+3.0)<1e-8)
        for t in np.nonzero(degen)[0]:
            tri=[int(ms[i]),int(ms[sel[t,0]]),int(ms[sel[t,1]])]
            for m4 in ms:
                if int(m4) not in tri:candidates.add(tuple(sorted(tri+[int(m4)])))
    good=[]
    for modes in candidates:
        if primitive_level(n,modes)!=n:continue
        cc=[2*np.cos(2*np.pi*m/n) for m in modes]
        e2=sum(cc[i]*cc[j] for i,j in itertools.combinations(range(4),2))
        if abs(e2+3)>1e-7:continue
        aa=[-x for x in cc]
        E1=sum(aa)
        E3=sum(aa[i]*aa[j]*aa[k] for i,j,k in itertools.combinations(range(4),3))
        E4=aa[0]*aa[1]*aa[2]*aa[3]
        tauf=E1*(3*E1+E3)-E4
        if abs(tauf)<1e-7:continue
        if exact_ok(n,modes):good.append(modes)
    return sorted(good)

ap=argparse.ArgumentParser()
ap.add_argument('lo',type=int);ap.add_argument('hi',type=int)
ap.add_argument('--skip-covered',action='store_true',help='skip n divisible by 10,24,28,42')
args=ap.parse_args();covered=(10,24,28,42);found=[]
for n in range(args.lo,args.hi+1):
    if args.skip_covered and any(n%m==0 for m in covered):continue
    good=search_one(n)
    if good:
        found.append(n);print(f"n={n}: {len(good)} exact positive certificate(s); first modes={good[0]}",flush=True)
    elif n%25==0:
        print(f"checked through n={n}",flush=True)
print("\nprimitive levels found:",found)
if args.skip_covered:
    print("(levels divisible by 10,24,28,42 were skipped)")
print("NOTE: absence of hits is computational evidence, not a nonexistence proof, because candidate generation uses floating-point screening.")
