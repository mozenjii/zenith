/* Exact zero forcing number of generalized Petersen graphs P(n,k) by exhaustive search.
   Vertices: u_i = i, v_i = n+i, for i in 0..n-1.  Requires 2n <= 64. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned long long u64;

static int N2;
static u64 adj[64];

static void build(int n, int k) {
    N2 = 2 * n;
    for (int i = 0; i < N2; i++) adj[i] = 0ULL;
    for (int i = 0; i < n; i++) {
        int u = i, v = n + i;
        int un = (i + 1) % n, up = (i - 1 + n) % n;
        adj[u] |= 1ULL << un; adj[u] |= 1ULL << up; adj[u] |= 1ULL << v;
        adj[v] |= 1ULL << u;
        adj[v] |= 1ULL << (n + (i + k) % n);
        adj[v] |= 1ULL << (n + (i - k % n + n) % n);
    }
}

/* returns 1 if the blue set S forces the whole graph */
static int forces(u64 S) {
    u64 full = (N2 == 64) ? ~0ULL : ((1ULL << N2) - 1);
    int changed = 1;
    while (changed) {
        changed = 0;
        u64 T = S;
        while (T) {
            int b = __builtin_ctzll(T); T &= T - 1;
            u64 w = adj[b] & ~S;
            if (w && (w & (w - 1)) == 0) { S |= w; changed = 1; }
        }
        if (S == full) return 1;
    }
    return S == full;
}

/* exhaustive test: does any r-subset force? */
static int exists_forcing_set(int r, u64 *witness) {
    int idx[16];
    for (int i = 0; i < r; i++) idx[i] = i;
    while (1) {
        u64 S = 0;
        for (int i = 0; i < r; i++) S |= 1ULL << idx[i];
        if (forces(S)) { *witness = S; return 1; }
        int i = r - 1;
        while (i >= 0 && idx[i] == N2 - r + i) i--;
        if (i < 0) break;
        idx[i]++;
        for (int j = i + 1; j < r; j++) idx[j] = idx[j - 1] + 1;
    }
    return 0;
}

int main(int argc, char **argv) {
    int nlo = atoi(argv[1]), nhi = atoi(argv[2]), k = atoi(argv[3]);
    int rmax = (argc > 4) ? atoi(argv[4]) : 9;
    printf("n\tZ(P(n,%d))\twitness\n", k);
    for (int n = nlo; n <= nhi; n++) {
        if (2 * n > 64) { printf("%d\tSKIP (2n>64)\n", n); continue; }
        if (k >= (n + 1) / 2) { printf("%d\tSKIP (k>=n/2)\n", n); continue; }
        build(n, k);
        int found = 0;
        for (int r = 1; r <= rmax && !found; r++) {
            u64 w = 0;
            if (exists_forcing_set(r, &w)) {
                printf("%d\t%d\t\t", n, r);
                for (int i = 0; i < N2; i++) if (w >> i & 1ULL) {
                    if (i < n) printf("u%d ", i); else printf("v%d ", i - n);
                }
                printf("\n"); fflush(stdout);
                found = 1;
            }
        }
        if (!found) { printf("%d\t>%d\n", n, rmax); fflush(stdout); }
    }
    return 0;
}
