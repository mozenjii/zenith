# Supplementary material for Weighted certificates over real and finite fields for generalized Petersen graphs

This supplement reproduces the exact symbolic, finite-field, and exhaustive-search checks reported in the manuscript. It is organized into `original/`, which preserves the supplied original validation material, and `extensions/`, which contains the added exact searches and validators.

The manuscript’s theorems remain the authoritative statement of the arguments. The finite-field identities are exact polynomial identities, while the exhaustive zero-forcing computation establishes only the displayed finite range.

## Requirements

Python 3.10 or later, SymPy, and a C11 compiler are sufficient. The Python requirements of the original material are in `original/requirements.txt`.

## Original checks

From `original/`:

```text
python verify_paper.py
python classify_rational.py
gcc -O3 -std=c11 zero_forcing.c -o zero_forcing
./zero_forcing 7 27
```

Recorded original-code audit logs are in `extensions/validation2_*`.

## Added checks

From `extensions/`:

```text
python verify_signed_classification.py
gcc -O3 -std=c11 exact_candidates.c -o exact_candidates
python exact_search.py ./exact_candidates 7 420 --output exact_search_all_7_420.json
python test_exact_search.py ./exact_candidates
python verify_finite_fields.py
gcc -O3 -std=c11 direct_zf_anchor.c -o direct_zf_anchor
./direct_zf_anchor 7 12 selftest
./direct_zf_anchor 13 64
python verify_coverage.py
```

`verify_finite_fields.py` confirms the finite-field divisibility identities, exact graph patterns, and direct modular ranks. The final range log is `direct_zf_rerun_13_64.txt`. The anchored program uses GCC-compatible unsigned 128-bit integers and supports `n <= 64`.

## Important scope distinction

The real symmetric certificates establish the stated maximum-nullity equalities. The finite-field matrices establish lower bounds for the ordinary zero forcing number through the field-independent kernel-restriction argument; they do not prove real maximum nullity. The computation through 64 does not prove the conjecture outside that range.
